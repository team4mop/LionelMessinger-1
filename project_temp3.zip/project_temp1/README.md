# Android Messenger App

## UI/UX

![Messenger](https://github.com/Climier-code/AndroidStudio/blob/master/img/Messenger.gif)

## 사용된 개념

- Database(Firebase)

- RecyclerView

- Adapter

- ViewHolder

- ...
